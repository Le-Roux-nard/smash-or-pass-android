package bzh.lerouxard.smashorpass.apiImplementation;

import android.os.AsyncTask;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.net.ssl.HttpsURLConnection;

public class GetRandomCharacterTask extends AsyncTask<Void, Void, Void> {
    private static String API_URL = "https://graphql.anilist.co/";
    private static String QUERY_STRING = "query charactersRandom ($pageNumber: Int, $not_in: [Int]) {Page(perPage: 1, page: $pageNumber) {characters(sort: FAVOURITES_DESC, id_not_in: $not_in) {id siteUrl image {large} name { native alternative alternativeSpoiler userPreferred full} gender media(perPage: 1, sort: POPULARITY_DESC) { nodes {title {romaji} isAdult}}}}}";
    private static int MAX_CHARS_IN_API = 129169;
    private static List<Integer> alreadyUsedCharactersIdList = new ArrayList<Integer>();

    public GetRandomCharacterTask() {
    }

    public Void doInBackground(Void... voids) {
        HttpsURLConnection request = null;
        try {
            Random r = new Random();
            JSONObject queryVariables = new JSONObject();
            queryVariables.put("pageNumber", r.nextInt(MAX_CHARS_IN_API));

            request = (HttpsURLConnection) new URL(API_URL).openConnection();
            request.setDoOutput(true);
            request.setRequestProperty("method", "POST");
            request.setUseCaches(false);
            request.setConnectTimeout(10000);
            request.setReadTimeout(10000);
            request.setRequestProperty("Content-Type", "application/json");

            JSONObject jsonParam = new JSONObject();
            jsonParam.put("query", QUERY_STRING);
            jsonParam.putOpt("variables", queryVariables);
            OutputStreamWriter out = new OutputStreamWriter(request.getOutputStream());
            out.write(jsonParam.toString());
            out.close();

            StringBuilder sb = new StringBuilder();
            int HttpResult = request.getResponseCode();
            if (HttpResult == HttpsURLConnection.HTTP_OK) {
                BufferedReader br = new BufferedReader(new InputStreamReader(
                        request.getInputStream(), "utf-8"));
                String line = null;
                while ((line = br.readLine()) != null) {
                    sb.append(line + "\n");
                }
                br.close();

                System.out.println("" + sb.toString());

            } else {
                System.out.println("["+request.getResponseCode() + "] " + request.getResponseMessage());
            }

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        } finally {
            if (request != null)
                request.disconnect();
        }
        return null;
    }

    protected void onPostExecute() {
        //TODO : do something
    }
}
