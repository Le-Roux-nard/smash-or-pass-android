package bzh.lerouxard.smashorpass.apiImplementation;

public interface Character {
    String id = null;
    String siteUrl = null;
    String image = null;
    String name = null;
    Gender gender = null;
    String mediaTitle = null;
    Boolean mediaIsAdult = false;
}
