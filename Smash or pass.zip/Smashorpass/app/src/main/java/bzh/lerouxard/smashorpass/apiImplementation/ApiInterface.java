package bzh.lerouxard.smashorpass.apiImplementation;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface ApiInterface {
    @POST("https://graphql.anilist.co/")  // your url
    @Headers("Content-Type: application/json")
    Call<String> getRandomChar(@Body ApiQuery model);
/// Call<String>   depend for result response

}
