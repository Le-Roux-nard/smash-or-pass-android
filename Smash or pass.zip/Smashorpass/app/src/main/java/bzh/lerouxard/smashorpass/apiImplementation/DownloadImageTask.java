package bzh.lerouxard.smashorpass.apiImplementation;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.widget.ImageView;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;

import bzh.lerouxard.smashorpass.MyApplication;


public class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
    final WeakReference<ImageView> imageView;
    final String imageName;

    public DownloadImageTask(WeakReference<ImageView> imageView, String imageName) {
        this.imageView = imageView;
        this.imageName = imageName;
    }

    public Bitmap doInBackground(String... urls) {
        String urldisplay = urls[0];
        Bitmap mIcon11 = null;
        try {
            InputStream in = new java.net.URL(urldisplay).openStream();
            mIcon11 = BitmapFactory.decodeStream(in);
            File file = new File(MyApplication.getAppContext().getCacheDir(), imageName + ".png");
            if (file.createNewFile()) {
                FileOutputStream filO = new FileOutputStream(file);
                OutputStream os = new BufferedOutputStream(filO);
                mIcon11.compress(Bitmap.CompressFormat.PNG, 100, os);
                os.close();
                filO.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mIcon11;
    }

    protected void onPostExecute(Bitmap result) {
        imageView.get().setImageBitmap(result);
    }


}
