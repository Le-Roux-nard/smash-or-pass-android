package bzh.lerouxard.smashorpass;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import bzh.lerouxard.smashorpass.apiImplementation.ApiClient;
import bzh.lerouxard.smashorpass.apiImplementation.ApiInterface;
import bzh.lerouxard.smashorpass.apiImplementation.ApiQuery;
import bzh.lerouxard.smashorpass.apiImplementation.ApiResponse;
import bzh.lerouxard.smashorpass.apiImplementation.GetRandomCharacterTask;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button startButton = findViewById(R.id.start_button);
        startButton.setOnClickListener(v -> {
            sendPost();
        });


    }

    private void sendPost() {

        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<String> call = apiInterface.getRandomChar(simpleData());

        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                if (response.isSuccessful()) {
                    String result = response.body();   // this response depend for result in server (get  any response you must edit result type in call )
                    Log.e("DEBUG", "onResponse: " + result);
                    //response from server
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                /// error response like disconnect to  server. failed to connect or etc....
            }
        });

    }

    private ApiQuery simpleData() {
        ApiQuery apiQuery = new ApiQuery();
        return apiQuery;
    }
}