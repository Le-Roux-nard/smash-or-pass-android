package bzh.lerouxard.smashorpass.apiImplementation;

public enum Gender {
    Male,
    Female,
}
