package bzh.lerouxard.smashorpass.apiImplementation;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ApiResponse {
    @SerializedName("slug")
    @Expose
    public String slug;

    @SerializedName("name")
    @Expose
    public String name;

    @SerializedName("background_image")
    @Expose
    public String backgroundImageLink;

    @SerializedName("id")
    @Expose
    public String id;

    @SerializedName("rating")
    @Expose
    public float rating;
}
